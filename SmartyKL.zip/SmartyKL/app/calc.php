<?php
// KONTROLER strony kalkulatora
require_once dirname(__FILE__).'/../config.php';

// załaduj Smarty
require_once _ROOT_PATH.'/lib/smarty/libs/Smarty.class.php';

use Smarty\Smarty;

// pobranie parametrów
function getParams(&$form){
	$form['fuel'] = isset($_REQUEST['fuel']) ? $_REQUEST['fuel'] : null;
	$form['burn'] = isset($_REQUEST['burn']) ? $_REQUEST['burn'] : null;
}

// walidacja parametrów
function validate(&$form,&$infos,&$msgs,&$hide_intro){

	if (!(isset($form['fuel']) && isset($form['burn']))) return false;

	$hide_intro = true;

	$infos [] = 'Przekazano parametry.';

	if ($form['fuel'] == "") $msgs [] = 'Nie podano ilości paliwa';
	if ($form['burn'] == "") $msgs [] = 'Nie podano średniego spalania';

	if (count($msgs)==0){
		if (!is_numeric($form['fuel'])) $msgs [] = 'Ilość paliwa nie jest liczbą';
		if (!is_numeric($form['burn'])) $msgs [] = 'Spalanie nie jest liczbą';
	}

	if (count($msgs)>0) return false;
	else return true;
}

// wykonaj obliczenia
function process(&$form,&$infos,&$msgs,&$result){

	$infos [] = 'Parametry poprawne. Wykonuję obliczenia.';

	$form['fuel'] = floatval($form['fuel']);
	$form['burn'] = floatval($form['burn']);

	if ($form['burn'] <= 0){
		$msgs [] = 'Spalanie musi być większe od 0';
		return;
	}

	$result = ($form['fuel'] / $form['burn']) * 100;
	$result = round($result,2) . " km";
}

// inicjacja zmiennych
$form = null;
$infos = array();
$messages = array();
$result = null;

getParams($form);
if (validate($form,$infos,$messages,$hide_intro)){
	process($form,$infos,$messages,$result);
}

// Smarty
$smarty = new Smarty();

$smarty->assign('app_url',_APP_URL);
$smarty->assign('root_path',_ROOT_PATH);
$smarty->assign('page_title','Kalkulator dystansu');
$smarty->assign('page_description','Obliczanie dystansu z paliwa i spalania');
$smarty->assign('page_header','Kalkulator dystansu');

$smarty->assign('form',$form);
$smarty->assign('result',$result);
$smarty->assign('messages',$messages);
$smarty->assign('infos',$infos);

$smarty->display(_ROOT_PATH.'/app/calc.html');