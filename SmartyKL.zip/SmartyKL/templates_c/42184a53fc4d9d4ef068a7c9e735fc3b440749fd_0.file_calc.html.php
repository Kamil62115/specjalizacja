<?php
/* Smarty version 5.4.2, created on 2026-03-11 12:59:31
  from 'file:C:\xampp\htdocs\SmartyKL/app/calc.html' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_69b15923205db7_29264229',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '42184a53fc4d9d4ef068a7c9e735fc3b440749fd' => 
    array (
      0 => 'C:\\xampp\\htdocs\\SmartyKL/app/calc.html',
      1 => 1773230221,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69b15923205db7_29264229 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\SmartyKL\\app';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_42275345069b159231e5d08_16490792', 'footer');
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_138267069969b159231ef2f7_62512862', 'content');
$_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "../templates/main.html", $_smarty_current_dir);
}
/* {block 'footer'} */
class Block_42275345069b159231e5d08_16490792 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\SmartyKL\\app';
?>

Kalkulator dystansu samochodu (paliwo + spalanie)
<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_138267069969b159231ef2f7_62512862 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\SmartyKL\\app';
?>


<h3>Kalkulator dystansu</h3>

<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->getValue('app_url');?>
/app/calc.php" method="post">
	<fieldset>
	
		<label for="fuel">Ilość paliwa (litry)</label>
		<input id="fuel" type="text" placeholder="np. 20" name="fuel" value="<?php echo $_smarty_tpl->getValue('form')['fuel'];?>
">

		<label for="burn">Średnie spalanie (l / 100 km)</label>
		<input id="burn" type="text" placeholder="np. 6.5" name="burn" value="<?php echo $_smarty_tpl->getValue('form')['burn'];?>
">

	</fieldset>
	
	<button type="submit" class="pure-button pure-button-primary">Oblicz dystans</button>
</form>

<div class="messages">

<?php if ((null !== ($_smarty_tpl->getValue('messages') ?? null))) {?>
	<?php if ($_smarty_tpl->getSmarty()->getModifierCallback('count')($_smarty_tpl->getValue('messages')) > 0) {?> 
		<h4>Wystąpiły błędy:</h4>
		<ol class="err">
		<?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('messages'), 'msg');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('msg')->value) {
$foreach0DoElse = false;
?>
		<li><?php echo $_smarty_tpl->getValue('msg');?>
</li>
		<?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
		</ol>
	<?php }
}?>

<?php if ((null !== ($_smarty_tpl->getValue('infos') ?? null))) {?>
	<?php if ($_smarty_tpl->getSmarty()->getModifierCallback('count')($_smarty_tpl->getValue('infos')) > 0) {?> 
		<h4>Informacje:</h4>
		<ol class="inf">
		<?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('infos'), 'msg');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('msg')->value) {
$foreach1DoElse = false;
?>
		<li><?php echo $_smarty_tpl->getValue('msg');?>
</li>
		<?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
		</ol>
	<?php }
}?>

<?php if ((null !== ($_smarty_tpl->getValue('result') ?? null))) {?>
	<h4>Możliwy dystans</h4>
	<p class="res">
	<?php echo $_smarty_tpl->getValue('result');?>
 km
	</p>
<?php }?>

</div>

<?php
}
}
/* {/block 'content'} */
}
